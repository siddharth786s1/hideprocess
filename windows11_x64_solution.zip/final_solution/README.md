# Windows 11 x64 Process Hider - Final Build Instructions

This package contains everything you need to correctly build and run the process hiding tool on a 64-bit Windows system. Follow these steps precisely to avoid errors.

## Step 1: Set Up The Correct Environment

You **MUST** use a command prompt with a 64-bit (x64) architecture target.

**1. Open the "x64 Native Tools Command Prompt for VS 2022" as an Administrator.**
   - Click the Start Menu.
   - Type `x64 native`.
   - Right-click on "x64 Native Tools Command Prompt for VS 2022" and select "Run as administrator".

**2. Navigate to this project's directory.**
   ```cmd
   cd C:\path\to\your\final_solution
   ```

## Step 2: Verify Your Environment

Before building, run the verification script to ensure everything is correct.

```cmd
verify_64bit.bat
```
- This script should show `[OK]` for all checks.
- If it shows an error about `x86` architecture, run `force_x64.bat` and then run `verify_64bit.bat` again.

## Step 3: Build the 64-bit Binaries

Once verification passes, compile the tool.

```cmd
build_x64.bat
```
- This will create `win_injector.exe` and `win_process_hider.dll`.

## Step 4: Check the Compiled Files

After the build is complete, check that the files are correct.

```cmd
check_binaries.bat
```
- This should confirm that both the `.exe` and `.dll` files are `x64`.

## Step 5: Run the Tool

You can now run the tool. The current version is for diagnostics and will not hide a process yet, but it will confirm the build is working.

```cmd
win_injector.exe notepad.exe
```
- You should see a success message confirming it's a 64-bit application.

---
If you follow these steps exactly, you will not get the "16-bit application" error because we are ensuring the entire process is configured for 64-bit.
